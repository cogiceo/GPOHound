$User = lowpriv
$Pass = lowpriv